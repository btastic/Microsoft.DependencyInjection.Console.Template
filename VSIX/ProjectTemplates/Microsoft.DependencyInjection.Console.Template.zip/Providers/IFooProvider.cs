﻿using System.Threading.Tasks;

namespace $safeprojectname$.Providers
{
    public interface IFooProvider
    {
        Task<string> CalculateFooAsync();
    }
}
