﻿using System.Threading.Tasks;

namespace $safeprojectname$.Services
{
    public interface IFooService
    {
        Task<string> GetFooAsync();
    }
}
